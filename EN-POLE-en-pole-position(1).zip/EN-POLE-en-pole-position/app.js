async function loadArticles() {
    const res = await fetch('/news');
    const articles = await res.json();
    const container = document.getElementById('articles');
    container.innerHTML = '';

    articles.forEach(article => {
        const div = document.createElement('div');
        div.className = 'article';
        div.innerHTML = `
            <a href="${article.link}" target="_blank">${article.title}</a>
            <small>${new Date(article.published).toLocaleString('fr-FR')}</small>
        `;
        container.appendChild(div);
    });
}

// Premier chargement
loadArticles();

// Rechargement automatique toutes les heures (3600000ms)
setInterval(loadArticles, 3600000);
